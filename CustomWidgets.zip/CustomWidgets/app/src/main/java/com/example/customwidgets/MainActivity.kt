package com.example.customwidgets

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat
import com.example.customwidgets.ui.theme.CustomWidgetsTheme
import org.w3c.dom.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.circular_progress_bar)
//        val customBar = findViewById<CustomBar>(R.id.customBar)
//        val button = findViewById<Button>(R.id.updateProgress)

//        val setText = findViewById<TextView>(R.id.setText)


//        var progress = 50
////        var text = 50
//        button.setOnClickListener {
//            progress += 10
////            text += 10
//            if (progress > 100) progress = 0
//            customBar.setProgress(progress)
////            setText.setText(text)
//            customBar.setBarColor(ContextCompat.getColor(this, R.color.teal_200))
//        }

//        val customSwitch = findViewById<CustomSwitch>(R.id.customSwitch)
//        customSwitch.setOnClickListener{
//            val status = if(customSwitch.isSwitchOn()) "ON" else "OFF"
//            Toast.makeText(this, "Switch is $status", Toast.LENGTH_SHORT).show()
//        }
        val circularProgress = findViewById<CircularProgressBar>(R.id.circularProgress)
        val button = findViewById<Button>(R.id.increaseProgress)

        var progress = 0
        button.setOnClickListener{
            progress +=10
            if(progress>100) progress = 0
            circularProgress.setProgressWithAnimation(progress)
        }
    }
}
//        {
//            CustomWidgetsTheme {
//                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
//                    Greeting(
//                        name = "Android",
//                        modifier = Modifier.padding(innerPadding)
//                    )
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun Greeting(name: String, modifier: Modifier = Modifier) {
//    Text(
//        text = "Hello $name!",
//        modifier = modifier
//    )
//}
//
//@Preview(showBackground = true)
//@Composable
//fun GreetingPreview() {
//    CustomWidgetsTheme {
//        Greeting("Android")
//    }
//}