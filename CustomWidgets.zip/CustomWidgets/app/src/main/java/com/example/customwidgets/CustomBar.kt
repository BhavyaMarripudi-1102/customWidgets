package com.example.customwidgets

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import androidx.compose.ui.geometry.Rect
import androidx.core.content.ContextCompat

class CustomBar @JvmOverloads constructor(
    context: Context,
    attr: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(
    context, attr, defStyleAttr
) {
    private var barColor = ContextCompat.getColor(context, android.R.color.holo_purple)
    private var progress = 50
//    private var text = 50

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val barWidth = width * (progress / 100f)
        val barHeight = height.toFloat()
        val rect = RectF(0f, 0f, barWidth, barHeight)

        paint.color = barColor
        canvas.drawRoundRect(rect, 30f, 30f, paint)
    }

    fun setProgress(value: Int) {
        progress = value.coerceIn(0, 100)
        invalidate()
    }

    fun setBarColor(color: Int) {
        barColor = color
        invalidate()
    }

//    fun setText(value : Int){
//        text = value.coerceIn(0,100)
//        invalidate()
//    }
}